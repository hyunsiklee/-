# -*- coding: utf-8 -*-
"""
Created on Tue Mar 23 16:23:54 2021

@author: IntekPlus
"""

import matplotlib.pyplot as plt
from matplotlib.image import imread

img = imread('c:\\hyunsik.JPG')

plt.imshow(img)
plt.show()