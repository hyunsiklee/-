# -*- coding: utf-8 -*-
"""

@author: ddonu
"""

# 30um 보정 타겟을 이용하여 카메라 영상에서의 분해능을 계산한다

# 타겟의 크기는 30um 크기
# 수행할 이미지들은 20배 이미지 현미경 배율이니까 굳이 xy를 나누지 말자.
# 칼라 이미지 
# 이진화 => 허프서클 하니까 필요 없네
# ROI 주기 => 허프서클 하니까 필요 없네
# 크기 계산하여 픽셀당 몇 나노 인지 계산



import cv2 
import numpy as np 
import matplotlib.pyplot as plt 


#image2 = cv2.imread("c:\x20.png", cv2.IMREAD_ANYCOLOR)

# 큰 이미지는 왜 안열리는가... 25메가 12메가 ....
image = cv2.imread('d:\sdf.jpg', cv2.IMREAD_GRAYSCALE)

assert image is not None

cimg = cv2.cvtColor(image,cv2.COLOR_GRAY2BGR)

realsize = int(input('plz input real size(nm) : '))
#calcsize = int(input('calc Pixel resolution(nm) : '))
#이걸이용해서 원이 작거나 큰경우 제거 하려 햇으나 두번째 파라미터로 조절됌

circles = cv2.HoughCircles(image,cv2.HOUGH_GRADIENT,1,20,
                            param1=50,param2=70,minRadius=0,maxRadius=0)

#print(circles)

circles = np.uint16(np.around(circles))
cnt = 0
sumrad = 0.0
for i in circles[0,:]:
    cnt+=1
    sumrad +=i[2]
    cv2.circle(cimg,(i[0],i[1]),i[2],(0,255,0),2)
    


plt.subplot(121)
plt.axis('off')
plt.title('original')
plt.imshow(image, cmap='gray')
plt.subplot(122)
plt.axis('off')
plt.title('detect circle')
plt.imshow(cimg)

#print(cnt)
#print(sumrad)
pxresolution = realsize/(sumrad/cnt*2)
print("pixel resolution = ",pxresolution,"nm")
