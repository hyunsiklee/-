'''
1. Feature Detection

- stitching.zip에서 4장의 영상(boat1, budapest1, newpaper1, s1)을 선택한 후에 Canny Edge와 Harris Corner를 검출해서 결과를 출력하는 코드를 작성하시오.

2. Matching

- stitching.zip에서 각 영상셋(boat, budapest, newpaper, s1~s2)에서 두 장을 선택하고 각 영상에서 각각 SIFT, SURF, ORB를 추출한 후에 매칭 및 RANSAC을 통해서 두 장의 영상간의 homography를 계산하고, 이를 통해 한 장의 영상을 다른 한 장의 영상으로 warping 하는 코드를 작성하시오.

3. Panorama

- CreaterStitcher 함수를 이용하여 4개의 영상 셋에 대해서 파노라마 이미지를 만드는 방법을 구현하시오.

4. Optical Flow

- stitching.zip에서 dog_a, dog_b 두 사진을 이용해서 Good Feature to Tracking을 추출하고 Pyramid Lucas-Kanade 알고리즘을 적용해서 Optical Flow를 구하는 코드를 작성하시오.

- stitching.zip에서 dog_a, dog_b 두 사진을 이용해서 Farneback과 DualTVL1 Optical Flow 알고리즘을 구하는 코드를 작성하시오.
'''

import cv2
import numpy as np
import glob

imagesPath = []


imagesPath.append(list(sorted(glob.glob('d:/last_data/3/*.jpg'))))
'''

imagesPath.append(list(sorted(glob.glob('d:/last_data/1/*.jpg'))))

imagesPath.append(list(sorted(glob.glob('d:/last_data/2/*.jpg'))))
imagesPath.append(list(sorted(glob.glob('d:/last_data/4/*.jpg'))))
imagesPath.append(list(sorted(glob.glob('d:/last_data/5/*.jpg'))))
imagesPath.append(list(sorted(glob.glob('d:/last_data/6/*.jpg'))))
'''
panos =[]
stitcher = cv2.createStitcher()
print('createStitcher')
for i in range(len(imagesPath)):
    images = []
    print('imagesPath')
    for img_path in range(len(imagesPath[i])):
        print('images open')
        images.append(cv2.imread(imagesPath[i][img_path], cv2.IMREAD_COLOR))
        print('images open done')
        images[img_path] = cv2.resize(images[img_path], dsize=(0, 0), fx=0.5, fy=0.5)
        print('images Resize done')
    ret, pano = stitcher.stitch(images)
    panos.append(pano)
    print('images stitch')
    images.clear()

    if ret == cv2.STITCHER_OK:
        sizeX = pano.shape[1]
        scale = 1800 / sizeX
        pano = cv2.resize(pano, dsize=(0,0), fx=scale, fy=scale)
        cv2.imshow('panorama', pano)
        cv2.waitKey()
        cv2.destroyAllWindows()

    else:
        print('error during stitching')
'''
ret, panolast = stitcher.stitch(panos)
print('images stitch')
pano.clear()

if ret == cv2.STITCHER_OK:
    sizeX = panolast.shape[1]
    scale = 1800 / sizeX
    panolast = cv2.resize(panolast, dsize=(0,0), fx=scale, fy=scale)
    cv2.imshow('panorama', panolast)
    cv2.waitKey()
    cv2.destroyAllWindows()
'''