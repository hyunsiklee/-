# -*- coding: utf-8 -*-
"""

@author: ddonu
"""
#4. 모폴로지 필터

#영상을 이진화한 후에 사용자로부터 Erosion, Dilation, Opening, Closing에 대한 선택과 횟수를 입력받아서 해당 결과를 출력하시오.


import cv2 
import numpy as np 
import matplotlib.pyplot as plt 

#image = cv2.imread('c:\BNW.png', 0)

image = cv2.imread('c:\Lena.png', cv2.IMREAD_GRAYSCALE)
assert image is not None
result, binary = cv2.threshold(image, -1, 1, cv2.THRESH_BINARY | cv2.THRESH_OTSU)


typ = int(input('1 Erosion, 2 Dilation, 3 Opening, 4 Closing : '))

sz = int(input('iterations : '))
kernel =np.ones((5, 5),np.uint8)

if typ==1:
    result = cv2.morphologyEx(binary, cv2.MORPH_ERODE, kernel, iterations=sz)
elif typ==2:
    result = cv2.morphologyEx(binary, cv2.MORPH_DILATE, kernel, iterations=sz) 
elif typ==3:
    result = cv2.morphologyEx(binary, cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)), iterations=sz) 
elif typ==4:
    result = cv2.morphologyEx(binary, cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)), iterations=sz) 

plt.subplot(131)
plt.axis('off')
plt.title('original')
plt.imshow(image, cmap='gray')

plt.subplot(132)
plt.axis('off')
plt.title('binary')
plt.imshow(binary, cmap='gray')


plt.subplot(133)
plt.axis('off')
plt.title('result')
plt.imshow(result, cmap='gray')
plt.tight_layout()
plt.show()
