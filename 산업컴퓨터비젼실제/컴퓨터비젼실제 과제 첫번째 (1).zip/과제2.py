# -*- coding: utf-8 -*-
"""

@author: ddonu
"""

#2. 공간 도메인 필터링

#각 픽셀에 임의의 값을 더해 노이즈를 생성하고, 사용자로부터 Bilateral filtering을 위한 diameter, SigmaColor, SigmaSpace를 입력받아 노이즈를 제거하고 노이즈 제거 전후의 영상을 출력하시오. (다양한 파라미터 변화를 통해 영상이 어떻게 변화하는지 보고서에 넣으시오.)

import cv2
import numpy as np
import math
import matplotlib.pyplot as plt


image = cv2.imread("c:\lena.png").astype(np.float32)/255

assert image is not None


noised = (image + 0.2 * np.random.rand(*image.shape).astype(np.float32))
noised = noised.clip(0,1)


diameter = int(input('Diameter( -1) : '))
sigmaColor = float(input('sigmaColor( 0.3) : '))
sigmaSpace = int(input('sigmaSpace( 10) : '))
bolat = cv2.bilateralFilter(noised, diameter, sigmaColor, sigmaSpace)

plt.figure(figsize=(12,4))
plt.subplot(131)
plt.axis('off')
plt.title('Original')
plt.imshow(image[:,:,[2,1,0]])
plt.subplot(132)
plt.axis('off')
plt.title('Noised')
plt.imshow(noised[:,:,[2,1,0]])
plt.subplot(133)
plt.axis('off')
plt.title('bilateralFilter')
plt.imshow(bolat[:,:,[2,1,0]])
plt.tight_layout()
plt.show()