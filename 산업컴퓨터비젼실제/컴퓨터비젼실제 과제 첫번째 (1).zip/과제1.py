# -*- coding: utf-8 -*-
"""

@author: ddonu
"""

#1. 히스토그램 평탄화

#사용자로부터 R, G, B 중의 하나의 채널을 입력받고 입력받은 채널에 대한 히스토그램을 그리고 평탄화를 한 후에 그 영상을 출력하시오. (선택받은 채널 이외의 채널 값은 변화하지 않음)

import cv2
import numpy as np
import math
import matplotlib.pyplot as plt


strChannel = input('Select color R G B : ')

image = cv2.imread("c:\lena.png")

assert image is not None

#선택한 채널 버퍼 생성
nChannel = 2
if strChannel == 'G':
    nChannel = 1
elif strChannel == 'B':
    nChannel = 0
grayImage = image[:,:,nChannel]

histOriginR, binsOriginR = np.histogram(image[:,:,2], 256, [0,255])
histOriginG, binsOriginG = np.histogram(image[:,:,1], 256, [0,255])
histOriginB, binsOriginB = np.histogram(image[:,:,0], 256, [0,255])


processedImage = image[:,:,[0,1,2]]
processedGrayImage = cv2.equalizeHist(grayImage)
processedImage[:,:,nChannel] = processedGrayImage

histEqualizedR, binsEqualizedR = np.histogram(processedImage[:,:,2], 256, [0,255])
histEqualizedG, binsEqualizedG = np.histogram(processedImage[:,:,1], 256, [0,255])
histEqualizedB, binsEqualizedB = np.histogram(processedImage[:,:,0], 256, [0,255])

#Display
plt.figure(figsize=[8,8])
plt.subplot(221)
plt.axis('off')
plt.title('Original color')
plt.imshow(image[:,:,[2,1,0]])

plt.subplot(222)
plt.axis('off')
plt.title('Equalized color')
plt.imshow(processedImage[:,:,[2,1,0]])

plt.subplot(223)
plt.title('Original histogram')
plt.fill(histOriginB) 
plt.fill(histOriginR)
plt.fill(histOriginG)

plt.subplot(224)
plt.title('Equalized histogram')
plt.fill(histEqualizedB)
plt.fill(histEqualizedR)
plt.fill(histEqualizedG)

plt.tight_layout()
plt.show()